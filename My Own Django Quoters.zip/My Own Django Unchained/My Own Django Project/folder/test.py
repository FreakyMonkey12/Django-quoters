from django.test import TestCase
from .models import Author

class AuthorTestCase(TestCase):
    def setUp(self):
        Author.objects.create(name="Test Author", bio="Test Bio")

    def test_author_creation(self):
        author = Author.objects.get(name="Test Author")
        self.assertEqual(author.bio, "Test Bio")


