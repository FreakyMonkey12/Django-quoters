from django.apps import AppConfig

class MyAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'  # Налаштування для автоматичного поля Primary Key
    name = 'myapp'  # Ім'я вашого додатку

    def ready(self):
        # Цей код виконається при завантаженні додатку
        print("MyApp is ready!")  # Приклад виводу повідомлення при завантаженні додатку

        # Тут ви можете додати код для виконання певних дій при завантаженні додатку,
        # таких як реєстрація сигналів або ініціалізація додаткових компонентів
