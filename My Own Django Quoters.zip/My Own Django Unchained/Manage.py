import os
import sys

if __name__ == "__main__":
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "quotes_project.settings")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)

#есть два варианта а = 1 или а = input
'''с помощью input мы спрашиваем у пользователя, например его возраст или погоду за окном
input принимает str(строки), текст, если мы напишем а = int(input('Сколько тебе лет?'))
то информация будет приниматься как int(цифры, числа)'''
#мы хотим узнать у пользователя его возраст, возраст это цифры, числа то есть надо написать 2 вариант input
if a >= 7 and a < 18:#если переменная а больше или равна 7 и(and) переменная а меньше 18
    print('Ты учишься в школе')
elif a >= 18:#если условие выше было не True(правдивым), то есть оно было ошибочным то выполняем это условие
    print('Ты окончил школу')
else:#иначе, если все выше перечисленные условия были ложными. else обычно пишут в самым последним
    print('Error')

